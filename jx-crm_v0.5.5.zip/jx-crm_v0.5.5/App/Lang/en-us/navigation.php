<?php
	return array(
		'SAVE_THE_SUCCESS'=>'Save the success!',
		'SAVE_THE_FAILURE'=>'Save failed!',
		'ANNOUNCEMENT'=>'announcement',
		'THE_ACCOUNTS_RECEIVABLE'=>'The accounts receivable',	
		'THE_ACCOUNTS_PAYABLE'=>'The accounts payable',	
		'VOUCHER'=>'voucher',	
		'PAYMENT_ORDER'=>'Payment order',	
		'PLEASE_FILL_OUT_THE_MENU_NAME'=>'Please fill out the menu name',	
		'THE_LINK_ADDRESS'=>'The link address',	
		'ADD_A_SUCCESS'=>'Add success!',
		'PARAMETER_ERRORS_ADD_FAILURE'=>'Parameter error, add failure!',
		'MODIFY_THE_SUCCESS'=>'Modify the success',
		'MODIFY_THE_FAILURE'=>'Modify the failure',
        'UNCHECK_ANY_MENU'=> 'Not chosen any menu not chosen any menu',
        'THE_MENU_SETTINGS'=> 'The menu Settings',
        'NAVIGATION_MENU_SETTINGS'=> 'Navigation menu Settings',
        'QUICKLY_ADD_MENU_SETTINGS'=> 'Quickly add menu Settings',
        'SAVE_THE_LOCATION'=> 'Save the location',
        'NAVIGATION_LOCATION_AT_THE_TOP'=> 'Navigation location: at the top',
        'NAVIGATION_LOCATION_MORE'=> 'Navigation location: more',
        'NAVIGATION_LOCATION_PERSONAL_CENTER'=> 'Navigation location: personal center',
        'MENU'=> 'menu',
        'LINK'=> 'link',
        'THIS_POSITION_IS_NOT_TO_ADD_THE_MENU'=> 'This position is not to add the menu',
        'THE_SELECTED_OPTIONS'=> 'The selected options',
        'PLEASE_SEND_THE_RIGHT'=> '<span style="font-size:14px;">Please send the right need shortcut options in drag to the left side menu options(<span style="font-size:14px;color:red;">note:Add items please select permission scope, otherwise click is invalid</span>)</span>',
		'ALL_THE_OPTIONS'=>'All the options',
		'CONTRACT'=>'contract',
		'SYSTEM_SETTINGS'=>'System Settings',
		'SYSTEM_BASIC_SETTINGS'=>'System basic Settings',
		'SMTP_SETTINGS'=>'SMTP Settings',
		'CUSTOM_FIELDS'=>'Custom fields',
		'SYSTEM_MENU_SETTINGS'=>'System menu Settings',
		'WEIXIN_PUBLIC_ACCOUNT_SETTINGS'=>'Micro letter public account Settings',
		'ADD_NAVIGATION_MENU'=>'Add a navigation menu',
		'CHECK_ALL'=>'Future generations',
		'EDITING'=>'The editor',
		'PROMPT'=>'*Hint: drag can change the menu sequence',
		'ADD_MENU'=>'Add menu',
		'EDIT_MENU'=>'The edit menu',
		'SURE_TO_DELETE_THE_MENU'=>'"Sure to delete the menu"+name+"?"',
		'MENU_NAME'=>'Menu name',
		'NAVIGATION_POSITION'=>'Navigation position',
		'TOP'=>'top',
		'MORE'=>'more',
		'SYSTEM'=>'system',
		'THE_LINK_ADDRESS'=>'The link address',
		'SUBMIT'=>'submit',
		'HEADLINE'=>'title',
		
		
		
		
		
		
		
		
		
	
	);