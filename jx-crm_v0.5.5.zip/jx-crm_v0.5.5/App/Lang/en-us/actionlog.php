<?php
	return array(
		'INVALIDATE_PARAMETER'=>'Parameter error',
		'OPERATE_LOG'=>'action log',
		'DELETE_LOG_SUCCESS'=>'The log was removed successfully!',
		'DELETE_RELATED_LOG_SUCCESS' =>	'Successfully deleted records',
		'DELETE_RELATED_LOG_FAILED'  =>	'Delete failed',
		'DELETE_FAILED_CONTACT_ADMINISTRATOR'=> 'Delete failed, contact your administrator!',
		'MY_LOG'=>'My log',
		'CREATE_TODAY'=>"Today's",
		'CREATE_THIS_WEEK'=>'This week',
		'CREATE_THIS_MONTH'=>"This month's",
		'VIEW_BY_LOG_CATEGORY'=>'According to the log type view',
		'FILTER'=>'Filter:',
		'ALL_THE_OPERATION'=>'All the operation',
		'EDIT'=>'The editor',
		'OPERATOR'=>'Operation of',
		'OPERATING_TIME'=>'Operating time',
		'MODULE'=>'The module',
		'CONTENT'=>	'content',
		'TIME'=>'time',
	
	
	);