<?PHP
 RETURN ARRAY(
	'THE MAIN CONTENTS ARE AS FOLLOWS'=>'%s主要内容如下:%s%s',
	'THE MAIN CONTENT'=>'主要评论内容:%s',
	'THE_IS' =>'了',
	'EMPLOYEE_INFORMATION' =>'员工信息',
 );